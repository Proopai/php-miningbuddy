*WARNING* This document is out of date and will be updated by Devilen
as soon as possible.



,.-;:;-.,,.-;:;-.,,.-;:;-.,,.-;:;-.,,.-;:;-.,,.-;:;-.,,.-;:;-.,,.-;:;-.,

      -- Thanks for considering ----------------------------------
       __  __ _       _             ____            _     _
      |  \/  (_)_ __ (_)_ __   __ _| __ ) _   _  __| | __| |_   _
      | |\/| | | '_ \| | '_ \ / _` |  _ \| | | |/ _` |/ _` | | | |
      | |  | | | | | | | | | | (_| | |_) | |_| | (_| | (_| | |_| |
      |_|  |_|_|_| |_|_|_| |_|\__, |____/ \__,_|\__,_|\__,_|\__, |
                              |___/                         |___/
      ---------------------------------  http://miningbuddy.net --
          
,.-;:;-.,,.-;:;-.,,.-;:;-.,,.-;:;-.,,.-;:;-.,,.-;:;-.,,.-;:;-.,,.-;:;-.,


,----::)} WELCOME
| 
|  Thank you for downloading MiningBuddy, the premier mining solution for
|  EVE-Online corporations who want to keep their mining business easy 
|  and simple, without having too much extra paperwork on their hands. 
| 
|  Miningbuddy is geared from ground up to be stable and secure - No one,
|  except those who are allowed to to so, can modify or change information
|  like payout rolls or ore amounts. Logging in is more secure that the
|  average internet banking portal, beeing close to paranoid.
|  
|  Over 3,000 downloads and one hundred hosted installations show that
|  MiningBuddy keeps its promise.
|  
|  On a sidenote, MiningBuddy outranks every other EvE Online related tool
|  hosted on sourceforge.net, even the killboards. There is hope:
|  Not everyone on eve is a cold blooded killer ;)
`-------------------------------------------------------------------------------


,----::)} FEATURES LIST
| 
| O Mining
|   - Naturally you can manage Mining operations (create, delete, lock..)
|   - Join and leave, with every action being logged.
|   - Keep track of what ore has been hauled.
|   - Detailed payout information, breakdown accuracy down to 1 second!
|   - Compare you score (TMEC) to other runs, see who is more efficient!
|   - Launch "inofficial" ops for yourself without payout.
|   - Set the ore quotes (payout tables)
|   - Keep track of those floating cans with the can management page.
|   - Kick or ban people from mining operations (who idle too much).
| 
| O Financial
|   - Fully automated payout system!
|   - Transfer ISK to other people.
|   
| O Security
|   - Paranoid Login and authing system.
|   - Denies double-logins.
|   - Does auto-ban IPs and Usernames.
|   - Fine grained access control. Give you the rights you want!
| 
| O Maintenance
|   - Easy user preferences screen.
|   - Add, delete and modify users.
|   - Easy site configuration screen that allows to set any settings without
|     tweaking the config file!
|   - Maintenance tools included (tho MiningBuddy is geared for
|                                 self-maintenance)
|   - Enable or disable modules with one mouse click.
|   - Disable ore types you do not use for slicker pages.
|  
| O Additional Modules
|   - Statistics: Once you have done a few mining operations have 
|                 a look at the statistics page. Every statistic 
|                 you can dream of is there.
|   - Events: Plan and keep record of events! People can join up so you
|             know just how much ressources you need.
|   - Lotto: Play lotto! Buy tickets and get rich!
|   - Online times: See who in your corporation is online, and at what times. 
|   - Ranks: Easy rank management will put everyone into place and
|            allow you to see your corps structure with a blink of an eye.
|   - Divisions: Group your pilots into divisions!
|   
| O Misc
|   - MiningBuddy is geared up from the base to use the most mininal
|     ressources possible. You can run MiningBuddy on a 25Mhz machine!
|   - Images are created on the fly and are cached for later use; this
|     decreases load times!
| 
| O Browser compatability
|   - In Game Browser
|   - Firefox
|   - Mozilla
|   - limited: Internet Explorer (NOT supported. If it breaks you get to keep
|                                 BOTH pieces.)  
| 
| 
|  The best thing is that MiningBuddy is a living, breathing product. If
|  you miss something you want its almost very possible that I will code
|  it in. It has undergone several complete code overhauls to accomodate
|  peoples wishes. If you experience any problems during installation or 
|  usage please visit the Homepage of MiningBuddy at 
| 
|                         http://miningbuddy.net
|                   
|  and feel free to use the forums!
`-------------------------------------------------------------------------------

,----::)} LICENSE
| 
| MiningBuddy is licensed under the BSD license. In short: you can do
| pretty much anything with it as long as a) the copyright header stays
| intact, b) you give credit to the original author, Christian Reiss,
| and c) you do not claim that you wrote it.
| 
| The license in detail:
| 
|  * MiningBuddy (http://miningbuddy.net)
|  * Copyright (c) 2005-2008 Christian Reiss.
|  * All rights reserved.
|  *
|  * Redistribution and use in source and binary forms,
|  * with or without modification, are permitted provided
|  * that the following conditions are met:
|  *
|  * - Redistributions of source code must retain the above copyright notice,
|  *   this list of conditions and the following disclaimer.
|  * - Redistributions in binary form must reproduce the above copyright
|  *   notice, this list of conditions and the following disclaimer in the
|  *   documentation and/or other materials provided with the distribution.
|  *
|  *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
|  *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
|  *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
|  *  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
|  *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
|  *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
|  *  TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
|  *  OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
|  *  OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
|  *  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
|  *  SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
|  
|  By installing and using this software you agree to the license.
`-------------------------------------------------------------------------------

,----::)} INSTALLATION
| 
|  To install and operate MinindBuddy you will need:
| 
|  > *NIX / Linux
|  > php5         5.x     
|  > MySQL        5.x   
|  > php5-gd      5.x
|  > php5-mysqli  5.x
|  > php5-pear    5.x
|  > php5-session 5.x
|  > php5-tidy    5.x (This is optional. You can turn it on or
|                          off in the configuration file.)
|  
|   All these modules are part of any base Linux installation.
|   Consult your Linux manual for installation of missing packages.
| 
|   .-- IMPORTANT -------------------------------------------------------
|   |
|   | > PHP 4 OR OLDER BELOW WILL NOT WORK WITH MININGBUDDY
|   |                        
|   | > Noone really tried installing MiningBuddy on a "Windows Server" 
|   |   to my knowledge by now. It May work. But I am not giving support
|   |   for Windows in any way. If you use Windows and it does
|   |   not work you are on your own. Sorry.
|   | 
|   | > If you run MiningBuddy over an SSL connection (https://) you need
|   |   to configure your PHP to include OpenSSL (php5-openssl) in order
|   |   to generate images and link to itsself.
|   |
|   `--------------------------------------------------------------------
| 
|   MiningBuddy expects all those modules to be correctly installed. It
|   does currently NOT check if they actually are. If you get class not
|   found errors or similar, chances are that you are missing one 
|   important module. If you do and are unable to install the module let
|   me know, I will then bundle the missing module with the next version
|   of miningbuddy.
| 
| 1. Unpack the MiningBuddy in a directory of your choice, and set up your
|    WebServer accordingly. Create a MySQL Username, Password and Database
|    for use with MiningBuddy. I recommend phpmyadmin - great tool to do
|    just that!
| 
| 2. Copy /etc/config-release.php to ./etc/config.{hostname}.php and edit
|    it accordingly. Most things in there are self-explanatory.
|    Replace {hostname} with your hostname, example: The demo installation
|    of MiningBuddy is located at http://demo.miningbuddy.net, so the
|    config file is config.demo.miningbuddy.net.php - easy enough, or?
| 
| 3. Make sure there is a web-server writable ./images/cache/{hostname}
|    directory. It's used to store dynamically generated images.
|   
| 4. Create the databases schemas. Database structures are in the 
|    /doc/sql/mysql-tables.txt file, for me copy&paste into mysql worked
|    just fine.
|    
|    $ mysql -u {username} -p {database name} < mysql-tables.txt
|   
| 5. Create an admin account. 
|    Open your webbrowser and point to your MiningBuddy installation.
|    If you installed it in the root of the subdomain mining.example.org
|    head to http://mining.example.org. You should see the login page
|    of your new MiningBuddy installation. Click "request account" and
|    fill the form out. The very first account created will recive full
|    admin privileges and will be activated right away.
|   
| 6. Head to your webserver with your browser and try the MiningBuddy.
| 
| MiningBuddy thrives from feedback. I *need* your wishes and problems
| to debug and enhance this program. And of course, if you like it, 
| Donations in form of ISK or Blueprints are gladly accepted :)
`-------------------------------------------------------------------------------


I hope you will enjoy MiningBuddy as much as I enjoyed coding it for you.

Cheers,
Christian "Tha'Vena" Reiss.